package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="/webapi")
public class FeedbackController {

	@Autowired
	FeedbackService s;//object of FeedbackService s
	
	//list all the records of a table
		@GetMapping("/allfeedback")
		public List<FeedbackEntity> getAllFeedback(){
			return s.getAllFeedback();
		}
		
		//insert feedback details into table
		//post mapping always execute post method and it is used to pass(give) values
		@PostMapping("/addfeedback") //@RequestBody is used to read object from brower(which we have passed)
		public void addFeedback(@RequestBody FeedbackEntity e) {
			s.addFeedback(e);
		}
}
