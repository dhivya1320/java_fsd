package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class FeedbackEntity {
	
	@Id
	@Column(name="user_id" ,updatable=false,nullable=false) //primary key and not null
	private int user_id;
	
	@Column(length=30)
	private String email;
	
	@Column(length=100)
	private String feedback;
	
	//constructor
	public FeedbackEntity() {
		super();
	}
	
	//parameterized constructor
	public FeedbackEntity(int user_id,String email,String feedback ) {
		super();
		this.user_id=user_id;
		this.email=email;
		this.feedback=feedback;		
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	

}
