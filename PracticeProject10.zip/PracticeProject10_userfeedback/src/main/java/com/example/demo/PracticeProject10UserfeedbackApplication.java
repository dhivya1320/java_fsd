package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeProject10UserfeedbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticeProject10UserfeedbackApplication.class, args);
	}

}
