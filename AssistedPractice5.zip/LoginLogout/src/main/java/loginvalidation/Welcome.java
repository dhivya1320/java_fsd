package loginvalidation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Welcome")
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
       public Welcome() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			response.setContentType("text/html;charset=UTF-8");
	        PrintWriter out = response.getWriter();
	
	        out.println("<h1>Dashboard</h1>");
	        String user=request.getParameter("txtuname");
			out.print("Welcome  "+user+ " to the DashBoard");
			out.print("<br><br><br><a href='LogOutSuc'>Logout</a>");

	}
}
