package logic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;


@WebFilter("/FirstServlet")
public class FirstFilter implements Filter {

    
    public FirstFilter() {

    }

	
	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		PrintWriter out=response.getWriter();
		String role=request.getParameter("role");
		if(role.equals("Accountant")) {
			chain.doFilter(request,response);
		}
			
		else {
			out.println("you are not allowed to access this page");
			
		}
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
	}

}
