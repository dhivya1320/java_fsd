package handson;
import java.util.Scanner;

public class typeCasting {
	
		public static void main(String[] args) {
			//implicit typecasting(lower datatype to higher datatype)
			
			System.out.println("Widening!!!\n"); //eg.char to int ,char to float;
			
			char c='V';
			System.out.println("Inital value(character): "+c);
			int d=c;
			System.out.println("Value After Widening(integer): "+d);
			
			char a='D';
			System.out.println("Inital value(character): "+a);
			float b=a;
			System.out.println("Value After Widening(float): "+b);
			
			//explicit typecasting(higher datatype to lower datatype)
			
			System.out.println("\nNarrowing!!!\n"); //eg.int to char ,float to int;
			Scanner sc=new Scanner(System.in);
			
			System.out.println("Enter an integer value");
			
			int c1=sc.nextInt();
			System.out.println("Inital value(integer): "+c1);
			char d1=(char) c1;
			System.out.println("Value After Narrowing(character): "+d1);
			
			float a1=78.56f;
			System.out.println("Inital value(float): "+a1);
			int b1=(int) a1;
			System.out.println("Value After Narrowing(integer): "+b1);
			
			
		}
	
}
