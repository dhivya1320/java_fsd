package handson;

abstract class AnonymousInnerClass {
	   public abstract void display();
	}

public class innerClass {

	private String msg="Inner Classes\n";

	 void display()
	 {  
		 class inner
		 {  
			 void msg()
			 {
				 System.out.println(msg);
			 }  
	     }  
		 
	     inner xl=new inner();  
	     xl.msg(); 
	  
	 } 
	 
	 class Inner2 {

			// show() method of inner2 class
			public void show()
			{

				// Print statement
				System.out.println("In a nested class method ...\n");
			}
		}
	 
	public static void main(String[] args) {
		
		innerClass  ob=new innerClass ();  
		ob.display();  
		
		innerClass.Inner2 c = new innerClass().new Inner2();

		// Calling show() method over above object created
		c.show();
		
		//ananymous class 
		
		AnonymousInnerClass ac = new AnonymousInnerClass() {

	         public void display() {
	            System.out.println("Anonymous Inner Class..");
	         }
	      };
	      
	      ac.display();
	}
}




	







 

 

