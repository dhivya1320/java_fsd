package handson;

public class Constructor {
	int rollno;
	String name;
	Constructor(){
		System.out.println("default constructor is created.\n");
	}
	
	void display() {
		System.out.println(rollno+" "+name+"\n");
	}
	public static void main(String args[])
	{  
	    //creating objects and passing values  
	   Constructor s1 = new Constructor();  

	    s1.display();  
	}  
}

