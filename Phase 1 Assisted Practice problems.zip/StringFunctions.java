package handson;

public class StringFunctions {


	public static void main(String[] args) {
	
		System.out.println("Functions of Strings!!!");
		
		String sl=new String("Simply learn");
		System.out.println(sl.length());

		//substring
		String sub=new String("Curriculum");
		System.out.println(sub.substring(2));
		
		//String Comparison
		String s1="World";
		String s2="Worrd";
		System.out.println(s1.compareTo(s2));

		//IsEmpty
		String s4="";
		System.out.println(s4.isEmpty());

		//toLowerCase
		String s5="WOrD";
		System.out.println(s5.toLowerCase());
		
		//replace
		String s6="WorRd";
		String replace=s6.replace('R', 'l');
		System.out.println(replace);

		//equals
		String x="Welcome to Mphasis";
		String y="WelcOME to Mphasis";
		System.out.println(x.equals(y));

		System.out.println("\n");
		System.out.println("Creating StringBuffer...");
		
		//Creating StringBuffer and append method
		StringBuffer s=new StringBuffer("Welcome to Core Java!");
		s.append("Welcome to Simply learning ");
		System.out.println(s);

		//insert method
		s.insert(0, 'w');
		System.out.println(s);

		//replace method
		StringBuffer sb=new StringBuffer("Happy");
		sb.replace(0, 2, "hAP");
		System.out.println(sb);

		//delete method
		sb.delete(0, 1);
		System.out.println(sb);
		
		
		//StringBuilder
		System.out.println("\n");
		System.out.println("Creating StringBuilder");
		StringBuilder sb1=new StringBuilder("Happy World.Happy ");
		sb1.append("Learning");
		System.out.println(sb1);

		System.out.println(sb1.delete(0, 1));

		System.out.println(sb1.insert(1, "Welcome"));

		System.out.println(sb1.reverse());
				
		//conversion	
		System.out.println("\n");
		System.out.println("Conversion of Strings to StringBuffer and StringBuilder:\n");
		
		String str = "Hello"; 
	    // conversion from String object to StringBuffer 
	    StringBuffer sbr = new StringBuffer(str); 
	    System.out.println("String to StringBuffer");
	    System.out.println(sbr); 
	      
	    // conversion from String object to StringBuilder 
	    
	    StringBuilder sbl = new StringBuilder(str); 
	    sbl.append("world"); 
	    System.out.println("\nString to StringBuilder");
	    System.out.println(sbl);              		


		
	}

}

	

	
