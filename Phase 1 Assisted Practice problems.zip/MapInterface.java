package handson;
import java.util.*;  

public class MapInterface {
	 public static void main(String args[]){
		 
		 //Hashmap...
		 System.out.println("\nCreating Hashmap");
		 HashMap<Integer,String> map=new HashMap<Integer,String>();//Creating HashMap    
		   map.put(1,"Mango");  //Put elements in Map  
		   map.put(2,"Apple");    
		   map.put(3,"Banana");   
		   map.put(4,"Grapes");    
		   for(Map.Entry m : map.entrySet()){    
			 System.out.println(m.getKey()+" "+m.getValue());   
		   }
			 
		//Treemap...
		System.out.println("\nCreating Treemap");
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();    
        mp.put(100,"Amit");    
        mp.put(102,"Ravi");    
        mp.put(101,"Vijay");    
        mp.put(103,"Rahul");    
          
        for(Map.Entry m1:mp.entrySet()){    
         System.out.println(m1.getKey()+" "+m1.getValue());    
        }    
        
        //Hashtable...
        System.out.println("\nCreating Hashtable");
        Hashtable<Integer,String> hm=new Hashtable<Integer,String>();  
        
        hm.put(100,"Amit");  
        hm.put(102,"Ravi");  
        hm.put(101,"Vijay");  
        hm.put(103,"Rahul");  
        
        for(Map.Entry m2:hm.entrySet()){  
         System.out.println(m2.getKey()+" "+m2.getValue());  
        }  
		 
	 }
	 
}



   
   