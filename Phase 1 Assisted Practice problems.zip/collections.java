package handson;

import java.util.*;

public class collections {
	public static void main(String[] args) {
		//creating arraylist
		System.out.println("Creating ArrayList");
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		list.add("Ravi");//Adding object in arraylist  
		list.add("Vijay");  
		list.add("Ravi");  
		list.add("Ajay");  	   
		System.out.println(list);  
		
		//creating vector
	      System.out.println("\n");
	      System.out.println("Creating Vector");
	      Vector<Integer> vec = new Vector();
	      vec.addElement(15); 
	      vec.addElement(30); 
	      vec.addElement(23); 
	      vec.addElement(74); 

	      System.out.println(vec);
		
		//creating linkedlist
	      System.out.println("\n");
	      System.out.println("Creating LinkedList");
	      LinkedList<String> al=new LinkedList<String>();  
	      al.add("Ravivarma");  
	      al.add("Vijayragavan");  
	      al.add("Ravikumar");  
	      al.add("Ajaydev");  
	      Iterator<String> itr=al.iterator();  
	      while(itr.hasNext())
	      {  
	    	  System.out.println(itr.next());  
	      }
	      
	    	       
	       //creating hashset
	       System.out.println("\n");
	       System.out.println("Creating HashSet");
	       HashSet<Integer> t=new HashSet<Integer>();  
	       t.add(12);  
	       t.add(13);  
	       t.add(14);
	       t.add(15);
	       System.out.println(t);
	       
	     //creating stack
	       	  System.out.println("\nCreating stack");

		      Stack<String> stack = new Stack<String>();  
		      stack.push("Ayush");  
		      stack.push("Garvit");  
		      stack.push("Amit");  
		      stack.push("Ashish");  
		      stack.push("Garima");  
		      stack.pop();  
		      Iterator<String> it=stack.iterator();  
		      while(it.hasNext())
		      {  
		    	  System.out.println(it.next());
		      }  
	       
	       //creating linkedhashset
	       System.out.println("\nCreating LinkedHashSet");
	       LinkedHashSet<Integer> s=new LinkedHashSet<Integer>();  
	       s.add(110);  
	       s.add(111);  
	       s.add(112);
	       s.add(113);	       
	       System.out.println(s);
	    } 
}


