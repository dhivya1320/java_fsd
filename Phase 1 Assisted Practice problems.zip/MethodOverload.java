package handson;

public class MethodOverload {
	
	public int mult(int m,int n) {
		return m*n;
	}
	public float mult(float m,float n) {
		return m*n;
	}
	public int mult(int m,int n, int o)
	{
		return m*n*o;
	}
	public static void main(String[] args) {
		MethodOverload mo=new MethodOverload();
		//changing the number of arguments
		System.out.println("Multiplication of 2 integer numbers: "+mo.mult(3,4));
		System.out.println("Multiplication of 3 integer numbers: "+mo.mult(3,4,5));
		//changing the datatype of arguments
		System.out.println("Multiplication of 2 float numbers: "+mo.mult(3.2f,2.0f));


	}
}
