package handson;
import java.util.regex.*;  

public class regularexImp {
	public static void main(String args[])
	{

		//. represents single character 
		System.out.println(Pattern.matches(
			"Simplylea.n", "Simplylearn"));

		//o* represents o occurs zero or more times
		System.out.println(
			Pattern.matches("happywo*d", "happywood"));
		
		//	[a-zA-Z]	a through z or A through Z, inclusive (range)
		System.out.println(
				Pattern.matches("[a-zA-Z]{4}", "arun"));
		
		System.out.println(
				Pattern.matches("[a-zA-Z]{4}", "aadhira")); 


	}
}

