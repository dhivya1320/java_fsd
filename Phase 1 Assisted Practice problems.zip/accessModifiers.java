package handson;
import java.util.Scanner;

class defModifier{
	//accessible within the package
	void display() 
	{
		System.out.println("*This is the default modifer.\n*Accessible within the same package.\n");
		
		//System.out.println("Rollno: "+rollno+"\nName: "+name);
	}
}
class privModifier
{
	//accessible within the class
	
	private void disp()
	{
		System.out.println("*This is the private access specifer.\n*Accessible within the class only.\n");
	}
	
}

class protectModifier
{
	protected void dispr() {
		System.out.println("*This is the protected modifer.\n*Accessible within same package and subclassess of different package.\n");
	}
}
class publicModifier
{
	public void dispu() 
	{
		System.out.println("*This is the public modifer.\n*Accessible from everywhere.");
		
	}
}
public class accessModifiers
{
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		defModifier d=new defModifier();
		d.display();
		
		protectModifier c =new protectModifier();
		c.dispr();
		
		publicModifier a=new publicModifier();
		a.dispu();
		
		/*privModifier p=new privModifier();
		p.disp();
		*/
		
		
		
		/*int roll=9074,rollno;
		String name="Vishwa",stud_name;
		System.out.println("Enter roll num");
		rollno=sc.nextInt();
		System.out.println("Enter name");
		stud_name=sc.next();
		d.display(rollno,stud_name);
		d.display(roll,name);*/
		
	}
}
