package handson;

import java.util.Scanner;

public class MethodCalling {
	static int add(int m,int n) {
		return m+n;
	}
	
	float sub(float m,float n) {
		return m-n;
	}
	
	public static void main(String[] args) {
		int m,n;
		float x=22.4f, y=12.4f;
		Scanner sc=new Scanner(System.in);
		
		// static method is called without creating the object.
		System.out.println("Enter first integer value:");
		m=sc.nextInt();
		System.out.println("Enter second integer value:");
		n=sc.nextInt();
		System.out.println("Addition using static method: "+ add(m,n));
		
		// non static method is called with creating the object.
		
		MethodCalling mc=new MethodCalling();
		System.out.println("Subtraction using non static method: "+ mc.sub(x,y));

		
	}
}
