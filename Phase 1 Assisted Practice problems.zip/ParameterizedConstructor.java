package handson;

public class ParameterizedConstructor {
	int rollno;
	String name;
	ParameterizedConstructor(int rollno,String name){
		this.rollno=rollno;
		this.name=name;
	}
	void display() {
		System.out.println("Paremeterized Constructor is created.\n" +rollno+" "+name+"\n");
	}
	public static void main(String args[]){  
	    //creating objects and passing values  
	   ParameterizedConstructor s2 = new ParameterizedConstructor(74,"Vishwa");  

	    s2.display();  
	   }  
}
