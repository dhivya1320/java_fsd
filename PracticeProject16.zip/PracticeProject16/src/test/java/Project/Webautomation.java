package Project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Webautomation {
	
	public static void main(String[] args) {
		
		WebDriver driver;
		// set path of Chromedriver executable
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHREE\\Downloads\\chromedriver_win32/chromedriver.exe");
	    
		// initialize new WebDriver session
	    driver = new ChromeDriver();
		 
		// navigate to the web site
	    driver.get("https://login.yahoo.com/account/create");
	      
	    	      
		driver.findElement(By.id("usernamereg-firstName")).sendKeys("Muthu"); //id locator for text box
		driver.findElement(By.id("usernamereg-lastName")).sendKeys("Deiveegan");
		
		driver.findElement(By.id("usernamereg-userId")).sendKeys("muthurockstar1314");
		
		driver.findElement(By.id("usernamereg-password")).sendKeys("Muthaiyan@1314");
		driver.findElement(By.id("usernamereg-birthYear")).sendKeys("1997");
		
		// maximized the browser window
		driver.manage().window().maximize();
		
		
	    WebElement searchIcon = driver.findElement(By.id("reg-submit-button"));//id locator for next button
	    searchIcon.click();
	      
	  	  

	}
	
	
}