package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminDAO {
	
	@Autowired
	AdminRepo repo;
	
	public Admin1 update(Admin1 a) {
		
		Admin1 an=repo.findById(a.getId()).orElse(null);
		an.setPassword(a.getPassword());
		return repo.save(an);
		
	}


}
