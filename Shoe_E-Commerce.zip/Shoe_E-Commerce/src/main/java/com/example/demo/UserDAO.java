package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserDAO {
	@Autowired
	UserRepo repo;
	
	public Users1 userSignup(Users1 u) {
		return repo.save(u);
	}
	public List<Users1> listofall() {
		return repo.findAll();
	}
	public void delete(int id) {
	 repo.deleteById(id);
}
	public Users1 updateByid(Users1 s) { 
	Users1 ss=repo.findById(s.getUserid()).orElse(null);
  ss.setUsername(s.getUsername());
  ss.setPassword(s.getPassword());
  ss.setEmail(s.getEmail());
  ss.setAddress(s.getAddress());
  ss.setPhno(s.getPhno());
   return repo.save(s);

}
}
