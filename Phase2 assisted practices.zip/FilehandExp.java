package Phase2assisted;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

//create new file

public class FilehandExp {

	public static void createFileUsingFileClass() throws IOException{
		File file=new File("C:\\Users\\SHREE\\Desktop\\Divya\\temp\\test1.txt");
		if(file.createNewFile()) {
			System.out.println("File is created");
		}
		else {
			System.out.println("File already exists");
		}
		
		//write in a file
		FileWriter w=new FileWriter(file);
		w.write("WELCOME FILE HANDLING");
		w.close();
	
	}
	public static List<String> readFileInList(String fileName)  throws IOException
	 { 
	  
	    List<String> lines = Collections.emptyList(); 
	    try
	    { 
	      lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);   
	    } 
	    catch (IOException e) 
	    { 
	      e.printStackTrace(); 
	    } 
	    return lines; 
	 } 
	
	   
	public static void modifyFile(String filePath, String oldString, String newString) throws IOException
	  {
	      File fileToBeModified = new File(filePath);
	      String oldContent = "";
	      BufferedReader reader = null;
	      FileWriter writer = null;
	      
	           reader = new BufferedReader(new FileReader(fileToBeModified));
	           String line = reader.readLine();
	           while (line != null) 
	            {
	               oldContent = oldContent + line + System.lineSeparator();
	               line = reader.readLine();
	            }
	           String newContent = oldContent.replaceAll(oldString, newString);
	           writer = new FileWriter(fileToBeModified);
	           writer.write(newContent);
	           reader.close();
               writer.close();

	          
	        
	       
	  }
	public static void deleteFile(String fileName)  throws IOException	    
	  { 
	        try
	        { 
	            Files.deleteIfExists(Paths.get(fileName)); 
	        } 
	        catch(NoSuchFileException e) 
	        { 
	            System.out.println("No such file/directory exists"); 
	        } 
	        catch(DirectoryNotEmptyException e) 
	        { 
	            System.out.println("Directory is not empty."); 
	        } 
	        catch(IOException e) 
	        { 
	            System.out.println("Invalid permissions."); 
	        } 
	        finally {
	        	 System.out.println("Deletion successful."); 
	        }
	       
	}

	      
	  

	public static void main(String[] args) throws IOException {
		createFileUsingFileClass();
		
		List l = readFileInList("C:\\Users\\SHREE\\Desktop\\Divya\\temp\\test1.txt");   
	    Iterator<String> itr = l.iterator(); 
	    while (itr.hasNext()) 
	      System.out.println(itr.next());
	    
	    modifyFile("C:\\Users\\SHREE\\Desktop\\Divya\\temp\\test1.txt", "FILE", "MODIFY");
        System.out.println("Updation done");
        
        List l1 = readFileInList("C:\\Users\\SHREE\\Desktop\\Divya\\temp\\test1.txt");  
        System.out.println("After Updation,the Contents in file: ");
	    Iterator<String> it = l1.iterator(); 
	    while (it.hasNext()) 
	      System.out.println(it.next());
	    
	    
	    deleteFile("C:\\Users\\SHREE\\Desktop\\Divya\\temp\\test.txt");
		}

	 
		
}


