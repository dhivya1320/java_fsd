package Airline_Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AddPlaceServlet")
public class AddPlaceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Connection connection;
	@Override
	public void init(ServletConfig config) throws ServletException {
		try {
			System.out.println(" DB connection started");
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/practice","root","shree@123");
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		PrintWriter out = response.getWriter();
		out.println("<body style='background-color:LightGray;'></body>");

		try (PreparedStatement statement = connection.prepareStatement("insert into places values(?,?)");) {
			statement.setString(1, source);
			statement.setString(2, destination);
			int rows = statement.executeUpdate();
			System.out.println("Rows : " + rows);
			out.println("<h1 style='color:green' align='center'>Places Added!!!</h1>");
			out.println("<br>");
			out.println("<h3  align='center' style='color:white;'><a href='HomePlace.jsp'>Home Place</a></h3>");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void destroy() {
		try {
			System.out.println("DB connection closed");
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


}
