package Airline_Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Admin")
public class Admin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");
		String Username = request.getParameter("user");
		String Password = request.getParameter("password");
		PrintWriter out=response.getWriter();
		out.println("<body style='background-color:LightGray;'></body>");
		if(Username.equals("admin")&&Password.equals("admin123")) {
			out.println("<h1 style='color:yellow' align='center'>Admin logged in successfully</h1>");
			out.println("<br>");
			out.println("<h3 align='center' style='color:white'><a href='Airlines.jsp'>Airlines</a></h3>");
			out.println("<h3 align='center' style='color:white'><a href='HomeFlight.jsp'>Flights</a></h3>");
			out.println("<h3 align='center' style='color:white'><a href='HomePlace.jsp'>Places</a></h3>");


	
		}else {
			out.println("<h1 align='center' style='color:green'>Invalid Credentials!!!</h1>");
			RequestDispatcher rd=request.getRequestDispatcher("/AdminLogin.jsp");
		}
		
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
