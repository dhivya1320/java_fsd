package Airline_Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ShowPlaceServlet")
public class ShowPlaceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Connection connection;
	@Override
	public void init(ServletConfig config) throws ServletException {
		try {
			System.out.println(" DB connection started");
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/practice","root","shree@123");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try (Statement statement = connection.createStatement();) {
			ResultSet results = statement.executeQuery("select * from places");
			PrintWriter out = response.getWriter();
			out.println("<body style='background-color:LightGray;'></body>");
			out.println("<h1 style='color:green;' align='center'>Places!!!</h1>");
			out.println("<table align='center'>");
			out.println("<tr>");
			out.println("<th><i><h3 style='color:white;'>Source</h3></i></th>");
			out.println("<th><i><h3 style='color:white;'>Destination</h3></i></th>");
			out.println("</tr>");
			while(results.next()) {
				out.println("<tr>");
				out.println("<td><i><h3 style='color:yellow;'>" + results.getString(1) + "</h3></i></td>");
				out.println("<td><i><h3 style='color:yellow;'>" + results.getString(2) + "</h3></i></td>");
				out.println("</tr>");
			}
			out.println("</table>");
			out.println("<h3 align='center' style='color:yellow;'><a href='HomePlace.jsp'>Home Place</a></h3>");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	@Override
	public void destroy() {
		try {
			System.out.println(" DB connection closed");
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}



}
