package Airline_Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FlightDetails")
public class FlightDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Connection connection;
	@Override
	public void init(ServletConfig config) throws ServletException {
		try {
			System.out.println(" DB connection started");
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/practice","root","shree@123");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		String date = request.getParameter("date");
		out.println("<body style='background-color:LightGray;'></body>");

		try { 
			PreparedStatement statement = connection.prepareStatement("select * from flight where source = ? AND destination = ? AND date = ?");
			statement.setString(1, source);
			statement.setString(2, destination);
			statement.setString(3, date);
			ResultSet results = statement.executeQuery();
			out.println("<h1 align='center' style='color:white'>Flight Details</h1>");
			out.println("<br>");
			
			if(results.next()) {
				out.println("<table align='center'>");
				out.println("<tr>");
				
				out.println("<th><h3>Source</h3></th>");
				out.println("<th><h3>Destination</h3></th>");
				out.println("<th><h3>Date</h3></th>");
				out.println("<th><h3>Flight Name</h3></th>");
				out.println("<th><h3>Price</h3></th>");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<td><h3 style='color:white'>" + results.getString(1) + "</h3></td>");
				out.println("<td><h3 style='color:white'>" + results.getString(2) + "</h3></td>");
				out.println("<td><h3 style='color:white'>" + results.getString(3) + "</h3></td>");
				out.println("<td><h3 style='color:white'>" + results.getString(4) + "</h3></td>");
				out.println("<td><h3 style='color:white'>" + results.getInt(5) + "</h3></td>");
				out.println("</tr>");
				out.println("</table>");
				out.println("<i><h3 align ='center' style='color:white'><a href='PersonalDetails.jsp'>Book Now</a><h3></i>");
				
			}
			else {
				out.println("<h3 align='center' style = 'color:red'>No flights are available right now!!</h1>");
				out.println("<i><h3 align='center' style = 'color:white'><a href='HomePage.jsp'>Home Page</a></p>");
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	@Override
	public void destroy() {
		try {
			System.out.println(" DB connection closed");
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


}
