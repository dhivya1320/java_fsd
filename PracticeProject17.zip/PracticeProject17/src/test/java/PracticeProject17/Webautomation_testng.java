package PracticeProject17;


import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
public class Webautomation_testng {
	WebDriver driver;
	
  

  @Test(priority = 1)
  public void register()
  {
	  
	  System.out.println("1.Register Testcase");
	// navigate to the web site
	    driver.get("https://login.yahoo.com/account/create");
	      
	    	      
		driver.findElement(By.id("usernamereg-firstName")).sendKeys("Muthu"); //id locator for text box
		driver.findElement(By.id("usernamereg-lastName")).sendKeys("Deiveegan");
		
		driver.findElement(By.id("usernamereg-userId")).sendKeys("muthurockstar1314");
		
		driver.findElement(By.id("usernamereg-password")).sendKeys("Muthaiyan@1314");
		driver.findElement(By.id("usernamereg-birthYear")).sendKeys("1997");
		
		// maximized the browser window
		driver.manage().window().maximize();
		
		
	    WebElement searchIcon = driver.findElement(By.id("reg-submit-button"));//id locator for next button
	    searchIcon.click();
	      
  }
  @Test(priority = 2)
  public void login() {
	
	  System.out.println("2.Login Testcase");
	  // navigate to the web site
      driver.get("http://login.yahoo.com/");
      
      
	  driver.findElement(By.id("login-username")).sendKeys("nidhikhandelwal09@yahoo.in"); //id locator for text box
      WebElement searchIcon = driver.findElement(By.id("login-signin"));//id locator for next button
     
      searchIcon.click();
  }
  
  @BeforeClass
  public void beforeClass() {
	
	  System.out.println("Before Class");
	  // set path of Chromedriver executable
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHREE\\Downloads\\chromedriver_win32/chromedriver.exe");
		  
		  
	  // initialize new WebDriver session
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
  }
  
  @AfterClass
  public void afterClass() {
	  System.out.println("After Class");
  }


  @AfterMethod
  public void afterMethod() {
	System.out.println("After Method");
	  // close and quit the browser
      //driver.quit();
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Before Method");
	  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
  }

 
  
  
}