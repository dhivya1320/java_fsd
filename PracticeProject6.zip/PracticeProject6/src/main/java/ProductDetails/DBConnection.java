package ProductDetails;
import java.sql.*;
public class DBConnection {
	static Connection c=null;
	public static Connection getConnection() throws SQLException, ClassNotFoundException{
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/practice";
			String user="root";
			String pwd="shree@123";
			c=DriverManager.getConnection(url,user,pwd);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return c;
	}
}
