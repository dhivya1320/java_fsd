package ProductDetails;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Display() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response)  {
		try {
			//get Connection
			Connection c=DBConnection.getConnection();
			String id=request.getParameter("productid");
			String str="select * from product_catalogue where productid="+id;
			Statement stmt=c.createStatement();
			//execute sql command and store output in resultset
			ResultSet rs=stmt.executeQuery(str);
			PrintWriter out=response.getWriter();
		    if (rs.next() == false) {
				out.println("Product Catalogue does not have product with such id");
		      }
		   
		    else { 
		    	do {
					out.println(rs.getInt("productid")+"\t"+rs.getString("name")+"\t"+rs.getFloat("price")+"\t"+rs.getInt("quantity"));

		    		} while (rs.next());
		    	}

				
		}catch(Exception e){
				e.printStackTrace();
			}
		
		}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
