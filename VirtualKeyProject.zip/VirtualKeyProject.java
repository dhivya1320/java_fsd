package BigPhaseProjects;

import java.io.File;
import java.util.Arrays;
import java.util.Scanner;

public class VirtualKeyProject{
	static Scanner sc=new Scanner(System.in);

	static void search(File f) {
		System.out.println("Enter a filename to search");
		String filename=sc.next();
		if(new File(f,filename).exists()) {
			System.out.println(filename+ " is found");
		}
		else {
			System.out.println("not found");
		}
		
	}
	static void addFile(File f){

		System.out.println("Enter a filename to add");
		String filename=sc.next();
		if(new File(f,filename).exists()) {
			System.out.println("Already exist");
		}else {
			File f1=new File(f,filename);//create File object with dirpath and dname
			f1.mkdirs();//checks whether the directory is created
			if(new File(f,filename).exists()) {
				System.out.println(filename+" added successfully");
			}
		}
		
	}
	static void deleteFile(File f) {
		System.out.println("Enter a filename to delete");
		String filename=sc.next();
		if(new File(f,filename).exists()) {
			File f1=new File(f,filename);//create File object with dirpath and dname
			f1.mkdirs();
			f1.delete();
			System.out.println(filename+" deleted successfully");
		}else {
			System.out.println("File not exists");
		}
		
	}
	static void Display(File f) {
		File arr[]=f.listFiles();
		Arrays.sort(arr);
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
	public static void main(String[] args) {
		File f=new File("C:\\Users\\SHREE\\Desktop\\Divya\\temp\\VirtualKey");
		if(f.mkdirs()) {
			System.out.println("Directory is created");
		}else {
			System.out.println("Directory is not created");

		}
		//Scanner sc=new Scanner(System.in);
		//File arr[]=f.listFiles();
		
		while(true) {
			System.out.println("Welcome to LockedMe.com ");
			System.out.println("1.Display the Current files in ascending order");
			System.out.println("2.Business Level Operations");
			System.out.println("3.Quit the Application\n");
			
			System.out.println("Enter your Choice");
			int choice=sc.nextInt();
			switch(choice) {
			case 1:
				Display(f);
				break;
			case 2:
				boolean op=true;
				while(op) {
					System.out.println("1. Add a user specified file to the application ");
					System.out.println("2. Delete a user specified file from the application");
					System.out.println("3. Search a user specified file from the application");
					System.out.println("4. Return to the Main Menu");
					System.out.println("5. Quit the Application");
					int choice2=sc.nextInt();
					switch(choice2) {
					case 1:
						addFile(f);
						break;
					case 2:
						deleteFile(f);
						break;
					case 3:
						search(f);
						break;
					case 4:
						op=false;
						break;
					case 5:
						System.out.println("Quitting...");
						System.exit(0);
					default:
						System.out.println("You have entered wrong option.Retry");
						
					}
				}
				break;
			case 3:
				System.out.println("Quitting...");
				System.exit(0);
			default:
				System.out.println("You have entered wrong option.Retry");
				break;
				
			}

		}
	}
}