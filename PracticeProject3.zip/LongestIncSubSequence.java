package PracticeProject3;

 
import java.io.*;
import java.lang.Math;
import java.util.*;

public class LongestIncSubSequence {
	static int LongestIncreasingSubsequenceLength(int a[])
	{
		if (a.length == 0) // boundary case
			return 0;

		int[] temp = new int[a.length];
		int length = 1; // always points empty slot in tail
		temp[0] = a[0];

		for (int i = 1; i < a.length; i++) {

			if (a[i] > temp[length - 1]) {
				// v[i] extends the largest subsequence
				temp[length++] = a[i];
			}
			else {
				
				int index = Arrays.binarySearch(
					temp, 0, length - 1, a[i]);

				
				if (index < 0)
					index = -1 * index - 1;

				temp[index] = a[i];
			}
		}
		return length;
	}
	public static void main(String[] args)
	{
		
		int v[] = { 0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15 };
		System.out.println("The array is");
		for(int i=0;i<v.length;i++) {
			System.out.print(v[i]+" ");
		}
		System.out.println("\n\nLength of Longest Increasing Subsequence is " + LongestIncreasingSubsequenceLength(v));
	}
}
