package com.phase1.projects;
import java.util.Scanner;

interface cal {
	int addition(int num1,int num2);
	int quotient(int num1,int num2);
	int remainder(int num1,int num2);
	int subtraction(int num1,int num2);
	int multiplication(int num1,int num2);
}

public class calculator implements cal {

	@Override
	public int addition(int m,int n) {
		int res=0;
		res=m+n;
		return res;
	}
	@Override
	public int subtraction(int m,int n) {
		
		int res=0;
		res=m-n;
		return res;
	}
	
	@Override
	public int multiplication(int m,int n) {
		int res=0;
		res=m*n;
		return res;
	}
	
	@Override
	public int quotient(int m,int n) {
		
		int res=0;
		if (n>0)
			res=m/n;
		return res;
	}
	@Override
	public int remainder(int m,int n) {
		int res=0;
		if (n>0)
			res=m%n;
		return res;
	}
	
	
	public static void main(String[] args) {
		calculator m=new calculator();
		Scanner sc=new Scanner(System.in);
		int res_add,res_sub,res_mul,res_qnt,res_rem;
	while(true) {
		System.out.println("Enter 2 values");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		 
		System.out.println("Choose an Operation\n1.Addition\t2.Subtraction\t3.Multiplication\t4.Quotient\t5.Remainder\t0.Exit:");
		int choice=sc.nextInt();
		switch(choice) {
			case 1:res_add=m.addition(num1, num2);
				   System.out.println("Result of addition: "+res_add);
				   break;
			case 2:res_sub=m.subtraction(num1, num2);
			       System.out.println("Result of subtraction: "+res_sub);
			       break;
			case 3:res_mul=m.multiplication(num1, num2);
			       System.out.println("Result of multipilication: "+res_mul);
			       break;
			case 4:res_qnt=m.quotient(num1, num2);
			       System.out.println("Result of quotient: "+res_qnt);
			       break;
			case 5:res_rem=m.remainder(num1, num2);
				   System.out.println("Result of remainder: "+res_rem);
				   break;
			case 0:System.out.println("...Quitting...");
				   System.exit(0);
			default:System.out.println("You enter wrong input.Choose the correct one");
					break;
		}
	  }
	} 
}
