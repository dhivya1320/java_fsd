package com.phase1.projects;
import java.util.regex.*;
import java.util.*;
public class EmailValidation {
	
	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		//Storing list of emailid in an array
		 
		 ArrayList<String> emails = new ArrayList<String>();  
		 emails.add("vishwa20@gmail.com");  
		 emails.add("pradeep23@gmail.com");  
		 emails.add("priya26@gmail.com");  
		 emails.add("mithra@gmail.com");  
		 emails.add("subash@gmail.com");  
		
		 emails.add( "muthu14@gmail.com");  
		 emails.add("barathi333@gmail.com");  
		 emails.add("albert@96@gmail.como");  
		 emails.add("deiveegan@gmail.com");  
		 emails.add("chandhna@gmail.com");  
		 emails.add("selva@gmail.com");  
		 
		 System.out.println("!!!This is Email Validation Program!!!\n");
	for(int i=0;i<2;i++) {	
		 System.out.println("Enter the EmailId to search");
		//Asking for user input from user to search emailid
	   String mail=sc.next();int op=1;
	   
	   //Validating email
	   for (String element : emails){
	         if (element.contains(mail)){
	        	 	op=0;
	               System.out.println("Valid mail id\n") ;
	         }
	      }
	      
	   if(op==1) {
		   System.out.println("invalid email id\n");
	   }
	    
	}

	
	}
}



		
