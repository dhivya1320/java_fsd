package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeProject12SpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticeProject12SpringSecurityApplication.class, args);
	}

}
