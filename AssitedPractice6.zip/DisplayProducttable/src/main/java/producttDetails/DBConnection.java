package producttDetails;
import java.sql.*;
public class DBConnection {
	static Connection c=null;
	//one connection is secure instead of multiple connection , so make it as static
	public static Connection getConnection() {//provide all the functionalities we can do in databases
	try {
		//step 1-require driver class -->
		//com.mysql.cj.jdbc.Driver --> getting from jar file in lib
		Class.forName("com.mysql.cj.jdbc.Driver");	//Class.forName -> tells class loader to load driver class in memory at runtime
		//step 2: Connection -Database url,username,password
		//drivermanager is available in java.sql
		String url="jdbc:mysql://localhost:3306/practice";
		String user="root";
		String password="shree@123";
		c=DriverManager.getConnection(url,user,password);
		}
	 catch(Exception e) {
		 e.printStackTrace();
	 }
		return c;
	}
}
