package table;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/InsertServlet")
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public InsertServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int rollnum=Integer.parseInt(request.getParameter("rollnum"));
		String name=request.getParameter("name");
		int marks=Integer.parseInt(request.getParameter("marks"));
		
		
		//Establish Connection with database
		try {
			Connection con=DBConnection.getConnection();	
			
			//Write Query
			
			String str="insert into student (rollnum,name,marks) values(?,?,?)";
			//string str= "update student set marks=? where rollno=?"
			//String str="delete from student where rollno=?"
			//to execute query create object of preparedSatement
			PreparedStatement  ps=con.prepareStatement(str);
			ps.setInt(1,rollnum );
			ps.setString(2, name);
			ps.setInt(3, marks);
						
			//execute query
			int ans =ps.executeUpdate();
			PrintWriter out=response.getWriter();
			if(ans>0)
				out.println("Record inserted");
			else
				out.println("Record not inserted");
		
			//close connection
			con.close();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		/*try {
			Connection c=DBConnection.getConnection();
			String name=request.getParameter("name");
			int roll=Integer.parseInt(request.getParameter("rollnum"));
			float marks=Float.parseFloat(request.getParameter("marks"));
			String str="insert into student(rollnum,name,marks) values(?,?,?)";
			PreparedStatement ps=c.prepareStatement(str);
			ps.setInt(1,roll);
			ps.setString(2,name);
			ps.setFloat(3, marks);
			
			int x=ps.executeUpdate(str);
			PrintWriter out=response.getWriter();
			if(x>0) {
				out.println("Insertion done successfully");
			}
			else {
				out.println("Error Occurred ");

			}
		} 
		
		
		catch (Exception e) {
			e.printStackTrace();
		} */
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
