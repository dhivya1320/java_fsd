package table;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public UpdateServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int rollnum=Integer.parseInt(request.getParameter("rollnum"));
		String name=request.getParameter("name");
		int marks=Integer.parseInt(request.getParameter("marks"));
		
		
		//Establish Connection with database
		try {
			Connection con=DBConnection.getConnection();	
			
			//Write Query
			
			//String str="Insert into student (rollno,name,marks) values(?,?,?)";
			String str= "update student set marks=? where rollnum=?";
			//String str="delete from student where rollno=?"
			//to execute query create object of preparedSatement
			PreparedStatement  ps=con.prepareStatement(str);
			ps.setInt(1,marks );
			ps.setInt(2,rollnum);
						
			//execute query
			int ans =ps.executeUpdate();
			PrintWriter out=response.getWriter();
			if(ans>0)
				out.println("Record updated");
			else
				out.println("Record not updated");
		
			//close connection
			con.close();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}/*try {
			Connection c=DBConnection.getConnection();
			int roll=Integer.parseInt(request.getParameter("rollnum"));
			float marks=Float.parseFloat(request.getParameter("marks"));
			String str="update student set marks=? where rollno=?";
			PreparedStatement ps=c.prepareStatement(str);
			ps.setInt(2,roll);
			ps.setFloat(1, marks);
			
			int x=ps.executeUpdate(str);
			PrintWriter out=response.getWriter();
			if(x>0) {
				out.println("Updation done successfully");
			}
			else {
				out.println("Error Occurred ");

			}
		} 
		
		
		catch (Exception e) {
			e.printStackTrace();
		} */

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
