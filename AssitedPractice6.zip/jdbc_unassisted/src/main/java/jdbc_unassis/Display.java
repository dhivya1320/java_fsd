package jdbc_unassis;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public Display() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,NullPointerException {

		try {
			
			InputStream in = getServletContext().getResourceAsStream("/webapp/config.properties");
			Properties props = new Properties();// it is predefine class
			props.load(in);
			Connection c = DBConnection.getMyConnection(props.getProperty("url"), props.getProperty("userid"),
					props.getProperty("password"));
			
			String str="select * from student";
			Statement stmt=c.createStatement();
			//execute sql command and store output in resultset
			ResultSet rs=stmt.executeQuery(str);
			PrintWriter out=response.getWriter();
			
			//read records from resultset
			while(rs.next()) {
				out.println(rs.getInt("rollnum")+"\t"+rs.getString("name")+"\t"+rs.getFloat("marks"));
				
			}
			c.close();

			
		} catch (NullPointerException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
