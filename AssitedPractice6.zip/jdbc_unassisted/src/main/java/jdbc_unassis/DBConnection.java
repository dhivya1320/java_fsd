package jdbc_unassis;

import java.sql.*;
public class DBConnection {
	static Connection con=null;
	public static Connection getMyConnection(String dbURL, String user, String pwd) {
		try{  
			
			//step1 load the driver class in memory at run time 
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//step2 create  the connection object 
			 con=DriverManager.getConnection(dbURL, user, pwd);
			//con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mphasisdetails","root","Comnet@123");  
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	
		return con;
		
		}
}

