package procedure;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	static Connection c=null;
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");	//Class.forName -> tells class loader to load driver class in memory at runtime
			
			String url="jdbc:mysql://localhost:3306/practice";
			String user="root";
			String password="shree@123";
			c=DriverManager.getConnection(url,user,password);
			}
		 catch(Exception e) {
			 e.printStackTrace();
		 }
			return c;
	}
}