package loginvalidation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Login() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String user=request.getParameter("txtuname");
		String pwd=request.getParameter("txtpassword");
		
		
		if(user.equals("Divya") && pwd.equals("Dhivya@123")) {
			HttpSession session=request.getSession(true);
			out.println("session id"+session.getId());
			session.setAttribute("Username", user);
			RequestDispatcher rs= request.getRequestDispatcher("Welcome");
			
			rs.forward(request,response);
		}
		else {
			out.println("Invalid Username or pwd");
			RequestDispatcher rs= request.getRequestDispatcher("ind.html");
			rs.include(request,response);
		}

		
	}

}
