package AssistedPractice4;

import java.util.Scanner;

public class MergeSort {
		static void  merging(int a[],int st,int mid,int end) {
			int i,j,k;
			int n=mid-st+1;
			int m=end-mid;
			int[] left=new int[n];
			int[] right=new int[m];
			for(i=0;i<n;i++) {
				left[i]=a[st+i];
			}for(j=0;j<m;j++) {
				right[j]=a[mid+1+j];
			}
			i=0;j=0;k=st;
			while(i<n && j<m) {
				if(left[i]<=right[j]) {
					a[k++]=left[i++];
				}else  {
					a[k++]=right[j++];
				}
				
			}
			while(i<n) {
				a[k++]=left[i++];
			}
			while(j<m) {
				a[k++]=right[j++];
			}
		}
		static void mergeSort(int a[], int beg, int end)  
		{  
		    if (beg < end)   
		    {  
		        int mid = (beg + end) / 2;  
		        mergeSort(a, beg, mid);  
		        mergeSort(a, mid + 1, end);  
		        merging(a, beg, mid, end);  
		    }  
		}  
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter size of array");
			int n=sc.nextInt();
			int[] a=new int[n];
			System.out.println("enter array elements");
			for(int i=0;i<n;i++) {
				a[i]=sc.nextInt();
			}
			
			mergeSort(a,0,n-1);
			for(int i=0;i<n;i++) {
				System.out.println(a[i]);
			}
			
		}
	}