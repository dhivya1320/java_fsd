package AssistedPractice4;

import java.util.Arrays;
import java.util.Scanner;

public class exponentialSearch {


	static int exponential(int a[],int n,int k) {
		if(a[0]==k) return 0;
		 int i=1;
		 while(i<n && a[i]<=k) {
			 i=i*2;
		 }
		 return Arrays.binarySearch(a, i/2, Math.min(i, n-1),k);
		
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size of array");
		int n=sc.nextInt();
		int[] a=new int[n];
		System.out.println("enter array elements");
		for(int i=0;i<n;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("enter an element to search");
		int k=sc.nextInt();
		int pos=exponential(a,n,k);
		System.out.println("position of "+k+": "+pos);
		
	}
}