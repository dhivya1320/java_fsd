package AssistedPractice4;
import java.util.Scanner;

public class SelectionSort {

	static void Selection(int a[]) {
		int n=a.length;
		for (int i = 0; i < n-1; i++)
        {
            // Find the minimum element in unsorted array
            int min_id = i;
            for (int j = i+1; j < n; j++)
                if (a[j] < a[min_id])
                    min_id = j;
  
            // Swap the found minimum element with the first
            // element
            int temp = a[min_id];
            a[min_id] = a[i];
            a[i] = temp;
        }
    }
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size of array");
		int n=sc.nextInt();
		int[] a=new int[n];
		System.out.println("enter array elements");
		for(int i=0;i<n;i++) {
			a[i]=sc.nextInt();
		}
		Selection(a);
		System.out.println("Array After Selection sort: ");
		for(int i=0;i<n;i++) {
			System.out.println(a[i]);
		}
	}
}
