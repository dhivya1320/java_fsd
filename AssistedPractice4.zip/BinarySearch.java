package AssistedPractice4;


import java.util.Scanner;

public class BinarySearch {
	
static int binary(int a[],int l,int e,int k) {
	int n=a.length;
	while(l<=e) {
		int mid=(l+e)/2;
		if(a[mid]==k) {
			return mid+1;
			
		}
		else if(a[mid]<k) {
			l=mid+1;
		}else {
			e=mid-1;
		}
	}
		
	return -1;
	
}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter size of array");
	int n=sc.nextInt();
	int[] a=new int[n];
	System.out.println("enter array elements");
	for(int i=0;i<n;i++) {
		a[i]=sc.nextInt();
	}
	System.out.println("enter an element to search");
	int k=sc.nextInt();
	int pos=binary(a,0,n,k);
	System.out.println("position of "+k+": "+pos);
	
}
}
