package AssistedPractice4;

import java.util.Scanner;

public class LinearSearch {

	static int search1(int a[],int k) {
		for(int i=0;i<a.length;i++) {
			if(k==a[i]) {
				return i+1;
			}
		}
		return -1;
	}
	public static void main(String[] args) {
		int k,n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size of an array");
		n=sc.nextInt();
		int[] a=new int[n];
		System.out.println("enter elements of array");
		for(int i=0;i<n;i++) {
			a[i]=sc.nextInt();

		}
		System.out.println("enter an integer to search in array");
		k=sc.nextInt();
		if(search1(a,k)!=-1) {
			System.out.println(k+" is found at the position "+ search1(a,k));
		}else {
			System.out.println("not found");
		}
		
	}
}
