package AssistedPractice3;

import java.util.Scanner;

public class  ArrayRotation  { 
public static void rotate(int[] a, int k) {
    		if(k > a.length) 
       			k=k%a.length;
 		int[] result = new int[a.length];
 		for(int i=0; i < k; i++){
        			result[i] = a[a.length-k+i];
 		}
 		int j=0;
    		for(int i=k; i<a.length; i++){
        			result[i] = a[j];
        			j++;
    		}
 		System.arraycopy( result, 0, a, 0, a.length );
}
public static void main(String[] args) {
        		int arr[] = { 2,5,3,1,0,7}; int k;
        		Scanner sc=new Scanner(System.in);
        		System.out.println("enter number of rotations");
        		k=sc.nextInt();
        		rotate(arr, k); 
        		System.out.println("Array after "+k+" rotations");
        		for(int i=0;i<arr.length;i++){
            			System.out.print(arr[i]+" ");
        		}
		}
}

