package Phase2;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;  
public class Filehandling {
	public static void createFileUsingFileClass() throws IOException{
		Scanner sc=new Scanner(System.in);
		File file = new File("C:\\Users\\SHREE\\Desktop\\Divya\\temp\\MNC.txt");
	      if (file.createNewFile()) {
	        System.out.println(file.getName()+"file is created!!!\n");
	      } else {
	        System.out.println("File already exists.\n");
	      }
		
		//write in a file
		FileWriter w=new FileWriter(file);
		w.write("WELCOME FILE HANDLING ");
		w.close();
		System.out.println("Successfully written on"+file.getName());
		
		
		//read a file
		
	      Scanner r = new Scanner(file);
	      System.out.println("\nContents in MNC.txt:");
	      while (r.hasNextLine()) 
	      {
	        String data = r.nextLine();
	        System.out.println(data);
	      }
	      r.close();
	      
	     //append a file
	      
	      	String str="Welcome to Append Function";
	      	System.out.println("\nEnter any statement to append:");
	      	String s=sc.nextLine();
	        try {
	            Files.write(Paths.get("C:\\Users\\SHREE\\Desktop\\Divya\\temp\\MNC.txt"), s.getBytes(), StandardOpenOption.APPEND);

	        } catch (IOException e) {
	        }
 	        System.out.println("\nData Successfully appended into file\n"); 
 	        
 	        //after appending
 		  Scanner r1 = new Scanner(file);

 	      System.out.println("After appending, contents in MNC.txt:\n");
 	      while (r1.hasNextLine()) 
 	      {
 	        String data = r1.nextLine();
 	        System.out.println(data);
 	      }
 	      r1.close();
 	        

	      
	}
  public static void main(String[] args) throws IOException {
	  createFileUsingFileClass();
  }
}
