package com.example.demo;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {
@ResponseBody
@RequestMapping("/greet")
	public String display() {
		return "<h1>Hi everyone! Welcome to AWS session!! Have a Nice Day!!!</h1>";
	}
	
}
