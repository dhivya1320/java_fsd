package com.example.demo;

public class Authentication {

	public boolean Isvalid(String user,String pwd) {
		if(user.equalsIgnoreCase("admin")&& pwd.equalsIgnoreCase("admin123"))
			return true;
		else
			return false;		
	}
}
