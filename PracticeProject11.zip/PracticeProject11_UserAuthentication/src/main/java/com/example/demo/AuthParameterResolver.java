package com.example.demo;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.ParameterContext;
import org.junit.jupiter.api.extension.ParameterResolutionException;
import org.junit.jupiter.api.extension.ParameterResolver;

public class AuthParameterResolver implements ParameterResolver {

	@Override
	public Object resolveParameter(ParameterContext p, ExtensionContext arg1) throws ParameterResolutionException {
		
		return new Authentication();
	}

	@Override
	public boolean supportsParameter(ParameterContext p, ExtensionContext arg1) throws ParameterResolutionException {
		return p.getParameter().getType()==Authentication.class;
	}

	
}
