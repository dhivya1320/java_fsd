package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(AuthParameterResolver.class)
class DependencyInjection 
{

	@Test
	@Tag("my-tag")
	void test(Authentication a) {
		assertEquals(true,a.Isvalid("admin", "admin123"));
	}

}
